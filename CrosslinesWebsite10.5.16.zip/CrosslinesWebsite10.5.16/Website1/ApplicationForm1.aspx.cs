﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;



public partial class _Default : System.Web.UI.Page
{
    string connectionString = ConfigurationManager.ConnectionStrings["ChristmasStore4ConnectionStringlaptop"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == true)
        {
            Label18.Text = ("Your text has been successfully entered");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection ChristmasStore = new SqlConnection(connectionString);
        {
            SqlCommand first = new SqlCommand("Insert into Client_Info(FirstName, LastName, DOB, Age, Pant_Size, Shirt_Size, Address1, Phone, City, State, ZIP, Ethnic, Income_1_Source, Income_2_Source, Income_3_Source, Gross_1, Gross_2, Gross_3) Values(@FirstName, @LastName, @DOB, @Age, @Pant_Size, @Shirt_Size, @Address1, @Phone, @City, @State, @ZIP, @Ethnic, @Income_1_Source, @Income_2_Source, @Income_3_Source, @Gross_1, @Gross_2, @Gross_3)", ChristmasStore);

            //first.Parameters.AddWithValue("@date", TextBox1.Text);
            first.Parameters.AddWithValue("@LastName", TextBox2.Text);
            first.Parameters.AddWithValue("@FirstName", TextBox3.Text);
            first.Parameters.AddWithValue("@DOB", TextBox4.Text);
            first.Parameters.AddWithValue("@AGE", TextBox5.Text);
            first.Parameters.AddWithValue("@Pant_Size", TextBox6.Text);
            first.Parameters.AddWithValue("@Shirt_Size", TextBox7.Text);
            first.Parameters.AddWithValue("@Address1", TextBox8.Text);
            first.Parameters.AddWithValue("@City", TextBox9.Text);
            first.Parameters.AddWithValue("@State", TextBox10.Text);
            first.Parameters.AddWithValue("@ZIP", TextBox11.Text);
            first.Parameters.AddWithValue("@Phone", TextBox12.Text);
            first.Parameters.AddWithValue("@Ethnic", TextBox13.Text);
            first.Parameters.AddWithValue("@Income_1_Source", TextBox14.Text);
            first.Parameters.AddWithValue("@Gross_1", TextBox15.Text);
            first.Parameters.AddWithValue("@Income_2_Source", TextBox16.Text);
            first.Parameters.AddWithValue("@Gross_2", TextBox17.Text);
            first.Parameters.AddWithValue("@Income_3_Source", TextBox18.Text);
            first.Parameters.AddWithValue("@Gross_3", TextBox19.Text);
           // first.Parameters.AddWithValue("@totalIncome", TextBox20.Text);

            ChristmasStore.Open();
            first.ExecuteNonQuery();
            ChristmasStore.Close();

        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("Default2.aspx", true);
    }

    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
}

//<add name="ChristmasStore4ConnectionString" connectionString="Data Source=.\SQLEXPRESS;AttachDbFilename=&quot;C:\Program Files (x86)\Microsoft SQL Server\MSSQL12.SQLEXPRESS\MSSQL\DATA\ChristmasStore4.mdf&quot;;Integrated Security=True;Connect Timeout=30"
//providerName="System.Data.SqlClient" />